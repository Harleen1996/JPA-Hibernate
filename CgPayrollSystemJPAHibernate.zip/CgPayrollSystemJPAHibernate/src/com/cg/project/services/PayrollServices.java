package com.cg.project.services;
import java.util.ArrayList;
import com.cg.project.beans.Associate;
import com.cg.project.exceptions.AssociateDetailNotFoundException;
import com.cg.project.exceptions.PayrollServicesDownException;

public interface PayrollServices {
	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation, String pancard, int yearlyInvestmentUnder8oC, double basicSalary, double epf, double companyPf, double accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException;
	double calculateNetSalary(int associateId) throws AssociateDetailNotFoundException, PayrollServicesDownException;
	Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException, PayrollServicesDownException;
	ArrayList<Associate> getAllAssociatesDetails() throws PayrollServicesDownException;
}
