package com.cg.project.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;
import com.cg.project.daoservices.AccountDAO;
import com.cg.project.daoservices.AccountDAOImpl;
import com.cg.project.exceptions.AccountBlockedException;
import com.cg.project.exceptions.AccountNotFoundException;
import com.cg.project.exceptions.BankingServicesDownException;
import com.cg.project.exceptions.InsufficientAmountException;
import com.cg.project.exceptions.InvalidAccountTypeException;
import com.cg.project.exceptions.InvalidAmountException;
import com.cg.project.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	static int pinNumberTry=0;
	//private static HashMap<Long, Integer> pinNumberTrack= new HashMap<Long, Integer>();
	private AccountDAO accountDAO= new AccountDAOImpl();
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
			if(!(accountType.equalsIgnoreCase("Savings") || accountType.equalsIgnoreCase("Current")))
				throw new InvalidAccountTypeException("Account type is not valid. Choose only Savings or Current");
			if(initBalance <1000)
				throw new InvalidAmountException("Balance should be more than 1000Rs. !!!");
			else{
				Account account= new Account(accountType, initBalance);
				long accountNo;
				accountNo=accountDAO.saveAccountDetails(account);
				if (accountNo==0)
					throw new BankingServicesDownException("Servers ae down! try again after some time");


				return accountNo;
			}
	}

	@Override
	public float depositAmount(long accountNo,float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.getDetails(accountNo);
			if(account == null) throw new AccountNotFoundException("Account details not found. Enter your account no. again");
			//if(account.getStatus().equalsIgnoreCase("Locked")) throw new AccountBlockedException("Your Account Blocked!!");
			account.setTransaction(new Transaction(amount, "Savings"));
			//System.out.println("bankImpl "+account);
			account= accountDAO.transactionEntry(account);
			account.setAccountBalance(account.getAccountBalance() + amount);
			//System.out.println("hey2 "+account);
			boolean updateAccount= accountDAO.updateAccount(account);
			//System.out.println(updateAccount);
			if(updateAccount)
				return account.getAccountBalance();
		return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account;
			account = accountDAO.getDetails(accountNo);
			if(account == null) throw new AccountNotFoundException("Account details not found. Enter your account no. again");
			if(account.getStatus().equalsIgnoreCase("Locked")) throw new AccountBlockedException("Your Account Blocked!!");
			pinNumberTry= accountDAO.getPinTrials(accountNo);
			//System.out.println("pin trials "+pinNumberTry);
			if(account.getPinNumber() != pinNumber && pinNumberTry ==3){
				account.setStatus("Locked");
				accountDAO.updateAccount(account);
				throw new InvalidPinNumberException("Your account get locked...!!!");
			}

			if(account.getPinNumber() != pinNumber && pinNumberTry <3){
				pinNumberTry=accountDAO.pinNumberTrialsUpdate(accountNo);
				System.out.println("Your Pin Trials "+pinNumberTry);
				throw new InvalidPinNumberException("Wrong Pin Number. Try again !!!");
			}
			//System.out.println("pin trials "+pinNumberTry);
			if(account.getAccountBalance() - amount < 1000)
				throw new InsufficientAmountException("Insufficient Amount in your account");
			pinNumber=0;
			account.setTransaction(new Transaction(amount, "Withdraw"));
			//System.out.println("bankImpl "+account);
			account= accountDAO.transactionEntry(account);
			account.setAccountBalance(account.getAccountBalance() - amount);
			//System.out.println("hey2 "+account);
			boolean updateAccount= accountDAO.updateAccount(account);
			//System.out.println(updateAccount);

			if(updateAccount)
				return account.getAccountBalance();
		return 0;
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
			Account account;
			account = accountDAO.getDetails(accountNoTo);
			if(account == null) throw new AccountNotFoundException("Wrong account number. Enter the recepient account number again!!!");
			account = accountDAO.getDetails(accountNoFrom);
			if(account==null) throw new AccountNotFoundException("Wrong account number. Enter the your account number again!!!");
			withdrawAmount(accountNoFrom, transferAmount, pinNumber);
			depositAmount(accountNoTo, transferAmount);
			return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account;
			account = accountDAO.getDetails(accountNo);
			if(account == null) throw new AccountNotFoundException("Account not found!!!");
			return account;

	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
			List<Account> accounts= accountDAO.getAllAccountDetail();
			return accounts;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
			List<Transaction> transactions= accountDAO.getAccountAllTransactions(accountNo);
			if(transactions.isEmpty())
				throw new AccountNotFoundException("Account Not Found. Try again!!!");
			return transactions;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
			Account account = accountDAO.getDetails(accountNo);
			if(account==null) throw new AccountNotFoundException("Account Not Found. Please Try Again!!!");
			return account.getStatus();
	}

}
