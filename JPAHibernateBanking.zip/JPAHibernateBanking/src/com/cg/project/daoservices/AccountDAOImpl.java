package com.cg.project.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;

public class AccountDAOImpl implements AccountDAO{
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	
	@Override
	public long saveAccountDetails(Account account) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account.getAccountNo();
	}

	@Override
	public Account getDetails(long accountNo) {
		EntityManager entityManager=factory.createEntityManager();
		return entityManager.find(Account.class,accountNo);
	}

	@Override
	public boolean updateAccount(Account account) {
		EntityManager entityManager=factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Account transactionEntry(Account account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAllAccountDetail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransactions(long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int pinNumberTrialsUpdate(long accountNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getPinTrials(long accountNo) {
		// TODO Auto-generated method stub
		return 0;
	}

}