package com.cg.project.daoservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.project.beans.Account;
import com.cg.project.beans.Transaction;

public interface AccountDAO {
	long saveAccountDetails(Account account);
	Account getDetails(long accountNo);
	boolean updateAccount(Account account);
	Account transactionEntry(Account account);
	List<Account> getAllAccountDetail();
	List<Transaction> getAccountAllTransactions(long accountNo);
	int pinNumberTrialsUpdate(long accountNo);
	int getPinTrials(long accountNo);
}