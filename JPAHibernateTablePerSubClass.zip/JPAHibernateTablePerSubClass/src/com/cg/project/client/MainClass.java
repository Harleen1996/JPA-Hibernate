package com.cg.project.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;

public class MainClass {

	public static void main(String[] args) {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	/*Employee employee= new Employee(112, "Deepak", "Mittal", "mittald6@gmail.com");
	PEmployee pemployee = new PEmployee(113, "Deepak", "Mittal", "mittald6@gmail.com");
	PEmployee pemployee1 = new PEmployee(1000, 1200, 1300);
	EntityManager entityManager=factory.createEntityManager();
	entityManager.getTransaction().begin();
	entityManager.persist(employee);
	entityManager.persist(pemployee);
	entityManager.persist(pemployee1);
	entityManager.getTransaction().commit();
	entityManager.close();*/
	

	}

}
