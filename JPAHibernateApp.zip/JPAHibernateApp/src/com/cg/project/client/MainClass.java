package com.cg.project.client;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.project.beans.Associate;
import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;


public class MainClass {

	public static void main(String[] args) {
		/*EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager entityManager=factory.createEntityManager();*/
		AssociateDAO dao=new AssociateDAOImpl();
		/*Associate associate=new Associate("Harleen","Aggarwal","Sr.Con","harleen@capgemini.com");
		associate=dao.save(associate);*/
		Associate associate=new Associate(15000,"Harleen","Aggarwal", "abc", "Sr.Con", "ANHPH123","harleen@capgemini.com", new BankDetails(1234, "HDFC", "HDFC007"),new Salary(50000, 5000, 5000));
		associate=dao.save(associate);
		int associateId=associate.getAssociateID();
		System.out.println("Associate Id= "+associate.getAssociateID());
		System.out.println(dao.findOne(1));
		System.out.println(dao.findOne(1233));
		ArrayList<Associate>list=dao.findAll();
		for (Associate associate2 : list) {
			System.out.println("list:"+associate2);
		/*int associateId=associate.getAssociateID();
		System.out.println("Associate Id= "+associate.getAssociateID());
		System.out.println(dao.findOne(1));
		System.out.println(dao.findOne(1233));
		ArrayList<Associate>list=dao.findAll();
		for (Associate associate2 : list) {
			System.out.println("list:"+associate2);
		}*/
		
	}
}
}
