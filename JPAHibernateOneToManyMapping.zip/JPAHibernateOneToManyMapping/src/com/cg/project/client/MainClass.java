package com.cg.project.client;

import javax.persistence.EntityManagerFactory;

import comcg.project.util.EntitymanagerFactoryProvider;

public class MainClass {

	public static void main(String[] args) {
	EntityManagerFactory factory=EntitymanagerFactoryProvider.getEntityManagerFactory();

	}

}
